#define	MAX(x,y)  ((x) > (y) ? (x) : (y))
#define	MIN(x,y)  ((x) > (y) ? (y) : (x))
#define	ABS(x)	  ((x) > 0   ? (x) : -(x))
#define	SGN(x)	  ((x) > 0   ? (1.0) : (-1.0))

#define	TRUE 1
#define	FALSE 0

