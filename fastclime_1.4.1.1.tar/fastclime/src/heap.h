void    hrise( int *key, int *iheap, int *heap, int cur);
void    hfall( int heapnum, int *key, int *iheap, int *heap, int cur);


