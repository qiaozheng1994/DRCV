void killtree( void );
void addtree( int data );
void deltree( int data );
int getfirst( void );
int getnext( void );
int getlast( void );
int getprev( void );

